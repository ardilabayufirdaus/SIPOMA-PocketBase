import os
import time
import logging
import pandas as pd
import yfinance as yf
import gc
from pathlib import Path
from datetime import datetime, timezone

# --- CONFIGURATION ---
DATA_DIR = Path('/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/tick_data')
LOG_PATH = '/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/tick.log'
BRIDGE_PATH = '/home/ardilabayufirdaus/.wine/drive_c/Program Files (x86)/MetaTrader 4/MQL4/Files/price_data.txt'

# Standard Yahoo Finance Symbols
PAIRS_MAP = {
    'EURUSD': 'EURUSD=X', 'GBPUSD': 'GBPUSD=X', 'USDJPY': 'USDJPY=X', 
    'AUDUSD': 'AUDUSD=X', 'USDCAD': 'USDCAD=X', 'USDCHF': 'USDCHF=X', 
    'NZDUSD': 'NZDUSD=X', 'EURJPY': 'EURJPY=X', 'GBPJPY': 'GBPJPY=X', 
    'AUDJPY': 'AUDJPY=X', 'CADJPY': 'CADJPY=X', 'CHFJPY': 'CHFJPY=X', 
    'NZDJPY': 'NZDJPY=X', 'EURGBP': 'EURGBP=X', 'EURCAD': 'EURCAD=X', 
    'GBPCAD': 'GBPCAD=X', 'XAUUSD': 'GC=F', 'BTCUSD': 'BTC-USD', 'ETHUSD': 'ETH-USD'
}

TIMEFRAMES = {
    'M5': ('5m', '5d'),  # Increased period for buffer
    'H4': ('1h', '20d')  # Download H1 and resample to H4 for reliability
}

logging.basicConfig(level=logging.INFO, filename=LOG_PATH, format='%(asctime)s - %(message)s')

def safe_write(path: Path, df: pd.DataFrame):
    try:
        tmp_path = path.with_suffix('.tmp')
        df.to_csv(tmp_path)
        os.replace(tmp_path, path)
    except Exception as e:
        logging.error(f"Write Error {path.name}: {e}")

def safe_read(path: Path) -> pd.DataFrame:
    try:
        if not path.exists(): return pd.DataFrame()
        df = pd.read_csv(path, index_col=0, parse_dates=True, on_bad_lines='skip')
        if not df.empty:
            df.index = pd.to_datetime(df.index, utc=True)
            df = df.sort_index()
            # Clean non-numeric or header junk
            df = df[df.index.notnull()]
        return df
    except Exception as e:
        logging.error(f"Read Error {path.name}: {e}")
        return pd.DataFrame()

def generate_bridge_file():
    """Generates price_data.txt for SAC-BRAIN in pipe format."""
    try:
        lines = []
        count = 0
        all_pairs = list(PAIRS_MAP.keys())
        
        for pair_name in all_pairs:
            for tf in ['M5', 'H4']:
                file_path = DATA_DIR / f'{pair_name}_{tf}.csv'
                df = safe_read(file_path)
                if not df.empty:
                    # Keep last 100 bars forindicators
                    subset = df.tail(100) 
                    # SAC-BRAIN V12.8.4 reads line by line and appends.
                    # To have NEWEST at BOTTOM of DataFrame, we write OLDEST first (Normal file order).
                    for idx, row in subset.iterrows():
                        ts = idx.strftime('%Y.%m.%d %H:%M')
                        # Symbol|TF|Timestamp|Open|High|Low|Close|Volume
                        # Indexing: 0:P, 1:TF, 2:TS, 3:O, 4:H, 5:L, 6:C, 7:V (Total 8)
                        line = f"{pair_name}|{tf}|{ts}|{row.get('Open',0)}|{row.get('High',0)}|{row.get('Low',0)}|{row.get('Close',0)}|{int(row.get('Volume',0))}"
                        lines.append(line)
                        count += 1
        
        if lines:
            # Atomic write via temp file
            tmp_bridge = BRIDGE_PATH + ".tmp"
            with open(tmp_bridge, 'w') as f:
                f.write("\n".join(lines))
            os.replace(tmp_bridge, BRIDGE_PATH)
            logging.info(f"BRIDGE SYNC: Written {count} lines for {len(all_pairs)} pairs.")
    except Exception as e:
        logging.error(f"Bridge Generation Error: {e}")

def update_pair_tf(pair_name: str, yf_symbol: str, tf_name: str, interval: str, period: str):
    file_path = DATA_DIR / f'{pair_name}_{tf_name}.csv'
    try:
        new_data = yf.download(yf_symbol, interval=interval, period=period, progress=False, auto_adjust=True)
        if new_data.empty: return

        if isinstance(new_data.columns, pd.MultiIndex):
            new_data.columns = new_data.columns.get_level_values(0)
        
        new_data.columns = [str(c).capitalize() for c in new_data.columns]
        new_data.index = pd.to_datetime(new_data.index, utc=True)
        
        # H4 logic: Resample H1 to H4
        if tf_name == 'H4' and interval == '1h':
            new_data = new_data.resample('4h').agg({
                'Open': 'first', 'High': 'max', 'Low': 'min', 'Close': 'last', 'Volume': 'sum'
            }).dropna()
        
        existing = safe_read(file_path)
        if not existing.empty:
            combined = pd.concat([existing, new_data])
            combined = combined[~combined.index.duplicated(keep='last')]
            combined = combined.sort_index()
            # Retention: 10 days for M5, 40 days for H4
            days = 10 if tf_name == 'M5' else 40
            cutoff = datetime.now(timezone.utc) - pd.Timedelta(days=days)
            combined = combined[combined.index >= cutoff]
            safe_write(file_path, combined)
        else:
            safe_write(file_path, new_data)
        
        gc.collect()
    except Exception as e:
        logging.error(f"Download Error {pair_name} {tf_name}: {e}")

def update_all():
    if not DATA_DIR.exists(): DATA_DIR.mkdir(parents=True)
    for pair_name, yf_symbol in PAIRS_MAP.items():
        logging.info(f"Syncing {pair_name} ({yf_symbol})...")
        for tf_name, (interval, period) in TIMEFRAMES.items():
            update_pair_tf(pair_name, yf_symbol, tf_name, interval, period)
            time.sleep(0.5)
        # Periodic bridge update
        generate_bridge_file()

if __name__ == '__main__':
    logging.info('🚀 Tick OMNI-BRIDGE V13.1.2 Professional Active')
    while True:
        try:
            update_all()
            logging.info(f'Full sync cycle complete.')
            time.sleep(180) # Slow frequency for stability
        except Exception as e:
            logging.error(f'Main Loop Error: {e}')
            time.sleep(30)
