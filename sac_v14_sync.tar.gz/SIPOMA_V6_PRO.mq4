//+------------------------------------------------------------------+
//|                                         SIPOMA_GOD_TRADER_MULTI  |
//|                                  Copyright 2026, AI Commander    |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, AI Commander"
#property link      "https://sipoma.online"
#property version   "1.40"
#property strict

extern string SymbolsToWatch = "XAUUSD,EURUSD,GBPUSD,GBPJPY,USDJPY";
extern string SignalFile = "C:\\signals\\trades.txt";
extern string DataFile = "C:\\signals\\bars.csv";
extern int CheckIntervalSeconds = 5;

int OnInit() { EventSetTimer(CheckIntervalSeconds); return(INIT_SUCCEEDED); }

void OnTimer() { WriteAllSymbolData(); CheckForSignals(); }

void WriteAllSymbolData() {
   int handle = FileOpen(DataFile, FILE_WRITE|FILE_CSV|FILE_ANSI, '|');
   if(handle != INVALID_HANDLE) {
      string syms[];
      ushort sep = StringGetCharacter(",", 0);
      int count = StringSplit(SymbolsToWatch, sep, syms);
      
      for(int i=0; i<count; i++) {
         WriteBarsForTF(handle, syms[i], PERIOD_M5, "M5");
         WriteBarsForTF(handle, syms[i], PERIOD_H1, "H1");
         WriteBarsForTF(handle, syms[i], PERIOD_D1, "D1");
      }
      FileClose(handle);
   }
}

void WriteBarsForTF(int handle, string pair, int tf, string tf_name) {
   for(int i=10; i>=0; i--) {
      FileWrite(handle, pair, tf_name, TimeToStr(iTime(pair, tf, i)), iOpen(pair, tf, i), iHigh(pair, tf, i), iLow(pair, tf, i), iClose(pair, tf, i), iVolume(pair, tf, i));
   }
}

void CheckForSignals() {
   int handle = FileOpen(SignalFile, FILE_READ|FILE_CSV|FILE_ANSI, '|');
   if(handle != INVALID_HANDLE) {
      string pair = FileReadString(handle);
      string action = FileReadString(handle);
      double entry = FileReadNumber(handle);
      double sl_pips = FileReadNumber(handle);
      double tp_pips = FileReadNumber(handle);
      double risk = FileReadNumber(handle);
      FileClose(handle);
      FileDelete(SignalFile);
      ExecuteTrade(pair, action, entry, sl_pips, tp_pips, risk);
   }
}

void ExecuteTrade(string pair, string action, double entry, double sl, double tp, double risk) {
   int type = -1;
   if(action == "BUY_MARKET") type = OP_BUY;
   if(action == "SELL_MARKET") type = OP_SELL;
   if(type == -1) return;
   double price = (type == OP_BUY) ? MarketInfo(pair, MODE_ASK) : MarketInfo(pair, MODE_BID);
   double pt = MarketInfo(pair, MODE_POINT);
   int dg = (int)MarketInfo(pair, MODE_DIGITS);
   double pips = (dg == 3 || dg == 5) ? pt * 10 : pt;
   double sl_val = (type == OP_BUY) ? price - sl * pips : price + sl * pips;
   double tp_val = (type == OP_BUY) ? price + tp * pips : price - tp * pips;
   double risk_amount = AccountEquity() * (MathMin(risk, 5.0) / 100.0);
   double lot = risk_amount / (sl * 10 * (MarketInfo(pair, MODE_TICKVALUE) / MarketInfo(pair, MODE_TICKSIZE)) * pt);
   double min_lot = MarketInfo(pair, MODE_MINLOT);
   double max_lot = MarketInfo(pair, MODE_MAXLOT);
   double lot_step = MarketInfo(pair, MODE_LOTSTEP);
   lot = MathMax(min_lot, MathMin(max_lot, NormalizeDouble(lot / lot_step, 0) * lot_step));
   OrderSend(pair, type, lot, price, 10, sl_val, tp_val, "SIPOMA MULTI-V1.4", 0, 0, clrGold);
}
