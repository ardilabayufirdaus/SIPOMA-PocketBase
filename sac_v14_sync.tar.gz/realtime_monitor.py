import os
import sqlite3
import time
import logging
from pathlib import Path

# --- CONFIGURATION V14.0 ---
DB_PATH = "/home/ardilabayufirdaus/ai-commander/commander_v2.db"
MT4_FILES = "/home/ardilabayufirdaus/.wine/drive_c/Program Files (x86)/MetaTrader 4/MQL4/Files"
STATS_BRIDGE = Path(MT4_FILES) / "account_stats.txt"

logging.basicConfig(level=logging.INFO, format="%(asctime)s - V14-SYNC - %(message)s")

def get_mt4_active_tickets():
    tickets = []
    if not STATS_BRIDGE.exists(): return []
    try:
        with open(STATS_BRIDGE, "r") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) > 1 and parts[0] == "ORDER":
                    tickets.append(int(parts[1]))
        return tickets
    except Exception as e:
        logging.error(f"Sync Error: {e}"); return []

def sync_trades_with_mt4(active_tickets):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.execute("SELECT ticket, pair FROM trade_history WHERE outcome = \"OPEN\" AND ticket IS NOT NULL")
        db_trades = cursor.fetchall()
        
        closed_count = 0
        for ticket, pair in db_trades:
            if int(ticket) not in active_tickets:
                conn.execute("UPDATE trade_history SET outcome = \"CLOSED\" WHERE ticket = ?", (ticket,))
                logging.info(f"[V14 SYNC] Trade #{ticket} ({pair}) marked as CLOSED.")
                closed_count += 1
        
        if closed_count > 0: conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"DB Sync Error: {e}")

if __name__ == "__main__":
    logging.info("V14 Sync Monitor Active (Outcome Protection)")
    while True:
        try:
            active_tickets = get_mt4_active_tickets()
            sync_trades_with_mt4(active_tickets)
            time.sleep(5) # Run sync every 5 seconds
        except Exception as e:
            logging.error(f"Loop Error: {e}"); time.sleep(5)
