import os
import json
import time
import asyncio
import logging
import sqlite3
import httpx
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from openai import OpenAI

load_dotenv()

# --- CONFIGURATION ---
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
XAI_API_KEY = os.getenv("XAI_API_KEY")
MODEL_ID = os.getenv("MODEL_ID", "grok-beta")
DB_PATH = '/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/commander_v2.db'
LOG_PATH = '/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/forex.log'

client = OpenAI(api_key=XAI_API_KEY, base_url="https://api.x.ai/v1")

# --- LOGGING ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- TOOLS ---
def query_db(query, params=()):
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.execute(query, params)
        rows = cursor.fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception as e:
        return f"Database Error: {e}"

async def run_terminal(command):
    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        return (stdout.decode() + stderr.decode())[:2000]
    except Exception as e:
        return f"Terminal Error: {e}"

async def handle_tool_calls(tool_calls):
    results = []
    for tool_call in tool_calls:
        name = tool_call.function.name
        args = json.loads(tool_call.function.arguments)
        
        logging.info(f"Executing Tool: {name} with {args}")
        
        if name == "query_db":
            res = query_db(args.get("query"))
        elif name == "run_terminal":
            res = await run_terminal(args.get("command"))
        elif name == "control_galaxy_trading":
            # Simplified ADB proxy for Galaxy control
            res = await run_terminal(f"adb shell {args.get('command')}")
        else:
            res = "Unknown tool"
            
        results.append({
            "tool_call_id": tool_call.id,
            "role": "tool",
            "name": name,
            "content": json.dumps(res) if isinstance(res, (dict, list)) else str(res)
        })
    return results

# --- HANDLERS ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Institutional Optimizer SAC V13.1 Active. Awaiting commands.")

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Basic health check
    uptime = await run_terminal("uptime -p")
    pm2 = await run_terminal("pm2 status")
    await update.message.reply_text(f"🏁 SYSTEM STATUS\n{uptime}\n\nProcesses:\n{pm2}")

async def logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lines = await run_terminal(f"tail -n 30 {LOG_PATH}")
    await update.message.reply_text(f"📝 LATEST LOGS\n```\n{lines}\n```", parse_mode='Markdown')

async def restart_cluster(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Restarting PM2 cluster...")
    await run_terminal("pm2 restart ecosystem.config.js")
    await update.message.reply_text("Cluster restart command issued.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text: return
    user = update.effective_user
    if str(user.id) != str(CHAT_ID):
        logging.warning(f"Unauthorized access attempt from {user.id}")
        return

    user_text = update.message.text
    messages = [
        {"role": "system", "content": "You are SAC V13.1 OMNI-MASTER. You control the SIPOMA server and Galaxy Trading Android phone. Use tools to query the DB or run commands. Respond in professional Indonesian Technical style."},
        {"role": "user", "content": user_text}
    ]

    try:
        response = client.chat.completions.create(
            model=MODEL_ID,
            messages=messages,
            tools=[
                {"type": "function", "function": {"name": "query_db", "description": "Query the trading database", "parameters": {"type": "object", "properties": {"query": {"type": "string"}}}}},
                {"type": "function", "function": {"name": "run_terminal", "description": "Run a linux command", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}}}},
                {"type": "function", "function": {"name": "control_galaxy_trading", "description": "Control Android Galaxy trading phone via ADB shell commands", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}}}}
            ]
        )
        
        msg = response.choices[0].message
        if msg.tool_calls:
            tool_results = await handle_tool_calls(msg.tool_calls)
            messages.append(msg)
            messages.extend(tool_results)
            
            final_response = client.chat.completions.create(
                model=MODEL_ID,
                messages=messages
            )
            await update.message.reply_text(final_response.choices[0].message.content)
        else:
            await update.message.reply_text(msg.content)
            
    except Exception as e:
        logging.error(f"Chat Error: {e}")
        await update.message.reply_text(f"⚠️ Error: {str(e)}")

# --- MAIN ---
if __name__ == "__main__":
    logging.info("Starting SAC V13.1 Bot Interface...")
    application = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("status", status))
    application.add_handler(CommandHandler("logs", logs))
    application.add_handler(CommandHandler("restart", restart_cluster))
    application.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_message))
    
    application.run_polling()
