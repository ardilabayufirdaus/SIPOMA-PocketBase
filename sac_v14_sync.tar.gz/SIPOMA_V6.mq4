//+------------------------------------------------------------------+
//|                                             SIPOMA_V6_Connector |
//|                                  Copyright 2026, AI Commander    |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, AI Commander"
#property link      "https://sipoma.online"
#property version   "1.20"
#property strict

extern string SignalFile = "C:\\signals\\trades.txt";
extern int CheckIntervalSeconds = 5;
extern double MaxRiskPerTrade = 5.0; // Batas Maksimal Resiko jika AI minta berlebihan

int OnInit()
{
   EventSetTimer(CheckIntervalSeconds);
   return(INIT_SUCCEEDED);
}

void OnTimer()
{
   int handle = FileOpen(SignalFile, FILE_READ|FILE_CSV|FILE_ANSI, '|');
   if(handle != INVALID_HANDLE)
   {
      string pair = FileReadString(handle);
      string action = FileReadString(handle);
      double entry = FileReadNumber(handle);
      double sl_pips = FileReadNumber(handle);
      double tp_pips = FileReadNumber(handle);
      double risk = FileReadNumber(handle);
      FileClose(handle);

      Print("SI POMA SIGNAL V1.20: ", pair, " | ", action, " | Risk: ", risk, "%");
      
      FileDelete(SignalFile);
      ExecuteTrade(pair, action, entry, sl_pips, tp_pips, risk);
   }
}

void ExecuteTrade(string pair, string action, double entry, double sl, double tp, double risk)
{
   int type = -1;
   if(action == "BUY_MARKET") type = OP_BUY;
   if(action == "SELL_MARKET") type = OP_SELL;
   if(type == -1) return;

   double pt = MarketInfo(pair, MODE_POINT);
   int dg = (int)MarketInfo(pair, MODE_DIGITS);
   double pips = (dg == 3 || dg == 5) ? pt * 10 : pt;
   double tick_val = MarketInfo(pair, MODE_TICKVALUE);
   double tick_size = MarketInfo(pair, MODE_TICKSIZE);

   // --- MONEY MANAGEMENT ENGINE ---
   double safe_risk = MathMin(risk, MaxRiskPerTrade);
   double risk_amount = AccountEquity() * (safe_risk / 100.0);
   
   // Hitung Lot berdasarkan Jarak SL (Pips)
   // Formula: Lot = Risk_Amount / (SL_in_Points * (TickValue / TickSize))
   double lot = risk_amount / (sl * 10 * (tick_val / tick_size) * pt);
   
   // Normalisasi Lot ke Batas Broker (Min, Max, Step)
   double min_lot = MarketInfo(pair, MODE_MINLOT);
   double max_lot = MarketInfo(pair, MODE_MAXLOT);
   double lot_step = MarketInfo(pair, MODE_LOTSTEP);
   lot = MathMax(min_lot, MathMin(max_lot, NormalizeDouble(lot / lot_step, 0) * lot_step));

   double price = (type == OP_BUY) ? MarketInfo(pair, MODE_ASK) : MarketInfo(pair, MODE_BID);
   if(price == 0) return;

   double sl_val = (type == OP_BUY) ? price - sl * pips : price + sl * pips;
   double tp_val = (type == OP_BUY) ? price + tp * pips : price - tp * pips;
   
   int ticket = OrderSend(pair, type, lot, price, 10, sl_val, tp_val, "SIPOMA V1.20-MM", 0, 0, clrGreen);
   
   if(ticket > 0) Print("MM ORDER SUCCESS! Lot: ", lot, " Pair: ", pair);
   else Print("MM ORDER FAILED! Error: ", GetLastError());
}
