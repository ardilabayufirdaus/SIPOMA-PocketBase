// --- V14.0 OMNI-PREDATOR BRIDGE EA ---
#property copyright "SIPOMA V14.0"
#property link      "https://sipoma.online"
#property version   "14.0"
#property strict

extern string SignalFile = "signals.txt";
extern string StatsFile = "account_stats.txt";
extern string PriceFile = "price_data.txt";
extern string ModifyFile = "modify.txt";
extern string CloseFile = "close.txt";

int OnInit() {
   EventSetTimer(1);
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason) {
   EventKillTimer();
}

void OnTimer() {
   WriteAccountStats();
   WritePriceData();
   CheckForSignals();
   ProcessModifications();
   ProcessClosures();
}

void WriteAccountStats() {
   int handle = FileOpen(StatsFile, FILE_WRITE|FILE_CSV|FILE_ANSI, '|');
   if(handle != INVALID_HANDLE) {
      FileWrite(handle, AccountBalance(), AccountEquity(), AccountMargin(), AccountFreeMargin(), AccountStopoutLevel());
      for(int i=0; i<OrdersTotal(); i++) {
         if(OrderSelect(i, SELECT_BY_POS)) {
            FileWrite(handle, "ORDER", OrderTicket(), OrderSymbol(), OrderType(), OrderOpenPrice(), OrderProfit(), OrderStopLoss(), OrderTakeProfit());
         }
      }
      FileClose(handle);
   }
}

void WritePriceData() {
   int handle = FileOpen(PriceFile, FILE_WRITE|FILE_CSV|FILE_ANSI, '|');
   if(handle != INVALID_HANDLE) {
      string pairs[] = {"EURUSD","GBPUSD","USDJPY","AUDUSD","USDCAD","USDCHF","NZDUSD","EURJPY","GBPJPY","AUDJPY","CADJPY","CHFJPY","NZDJPY","EURGBP","EURCAD","GBPCAD","XAUUSD"};
      for(int j=0; j<ArraySize(pairs); j++) {
         string s = pairs[j];
         FileWrite(handle, s, "M5", iOpen(s,5,0), iHigh(s,5,0), iLow(s,5,0), iClose(s,5,0), iVolume(s,5,0), TimeToStr(TimeCurrent()));
      }
      FileClose(handle);
   }
}

void CheckForSignals() {
   int handle = FileOpen(SignalFile, FILE_READ|FILE_CSV|FILE_ANSI, '|');
   if(handle != INVALID_HANDLE) {
      string p = FileReadString(handle);
      string a = FileReadString(handle);
      double entry = FileReadNumber(handle);
      double sl_val = FileReadNumber(handle);
      double tp_val = FileReadNumber(handle);
      double lot = FileReadNumber(handle); // V14.0: NOW ABSOLUTE LOT
      FileClose(handle);
      FileDelete(SignalFile);
      ExecuteTrade(p, a, entry, sl_val, tp_val, lot);
   }
}

void ExecuteTrade(string pair, string action, double entry, double sl, double tp, double lot) {
   int type = -1;
   if(action == "BUY_MARKET") type = OP_BUY;
   if(action == "SELL_MARKET") type = OP_SELL;
   if(type == -1) return;
   
   double price = (type == OP_BUY) ? MarketInfo(pair, MODE_ASK) : MarketInfo(pair, MODE_BID);
   
   // V14.0: ABSOLUTE LOT FROM BRAIN
   double min_lot = MarketInfo(pair, MODE_MINLOT);
   double max_lot = MarketInfo(pair, MODE_MAXLOT);
   double lot_step = MarketInfo(pair, MODE_LOTSTEP);
   double final_lot = MathMax(min_lot, MathMin(max_lot, NormalizeDouble(lot / lot_step, 0) * lot_step));
   
   int ticket = OrderSend(pair, type, final_lot, price, 10, sl, tp, "SAC V14.0", 0, 0, clrGold);
   if(ticket > 0) Print("SAC V14.0: Order Open success #", ticket);
   else Print("SAC V14.0: Order Open FAILED Error ", GetLastError());
}

void ProcessModifications() {
   int handle = FileOpen(ModifyFile, FILE_READ|FILE_CSV|FILE_ANSI, '|');
   if(handle != INVALID_HANDLE) {
      int ticket = (int)FileReadNumber(handle);
      double new_sl = FileReadNumber(handle);
      double new_tp = FileReadNumber(handle);
      FileClose(handle);
      FileDelete(ModifyFile);
      
      if(OrderSelect(ticket, SELECT_BY_TICKET)) {
         if(OrderStopLoss() != new_sl || OrderTakeProfit() != new_tp) {
            bool res = OrderModify(ticket, OrderOpenPrice(), new_sl, new_tp, 0, clrBlue);
            if(res) Print("SAC V14.0: Modify success #", ticket);
            else Print("SAC V14.0: Modify FAILED Error ", GetLastError());
         }
      }
   }
}

void ProcessClosures() {
   int handle = FileOpen(CloseFile, FILE_READ|FILE_CSV|FILE_ANSI, '|');
   if(handle != INVALID_HANDLE) {
      string pair = FileReadString(handle);
      FileClose(handle);
      FileDelete(CloseFile);
      for(int i=OrdersTotal()-1; i>=0; i--) {
         if(OrderSelect(i, SELECT_BY_POS)) {
            if(OrderSymbol() == pair) {
               double p = (OrderType() == OP_BUY) ? MarketInfo(pair, MODE_BID) : MarketInfo(pair, MODE_ASK);
               if(!OrderClose(OrderTicket(), OrderLots(), p, 10, clrRed)) Print("Error closing order: ", GetLastError());
            }
         }
      }
   }
}
