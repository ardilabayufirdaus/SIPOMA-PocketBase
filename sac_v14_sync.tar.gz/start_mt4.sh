#!/bin/bash
export DISPLAY=:10.0
export WINEPREFIX=/home/ardilabayufirdaus/.wine
wine "/home/ardilabayufirdaus/.wine/drive_c/Program Files (x86)/MetaTrader 4/terminal.exe" /portable
