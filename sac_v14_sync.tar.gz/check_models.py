from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()
client = OpenAI(api_key=os.getenv('XAI_API_KEY'), base_url='https://api.x.ai/v1')

try:
    models = client.models.list()
    for model in models.data:
        print(model.id)
except Exception as e:
    print(f'Error: {e}')
