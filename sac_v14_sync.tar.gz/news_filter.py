# news_filter.py - Forex Factory Integration V13.1
import httpx
import json
from datetime import datetime, timedelta, timezone

FF_CALENDAR_URL = 'https://nfs.faireconomy.media/ff_calendar_thisweek.json'
NEWS_CACHE = {'data': [], 'last_fetch': None}

def fetch_news_calendar() -> list:
    now = datetime.now()
    if (NEWS_CACHE['last_fetch'] is None or 
        (now - NEWS_CACHE['last_fetch']).seconds > 3600):
        try:
            resp = httpx.get(FF_CALENDAR_URL, timeout=10)
            NEWS_CACHE['data'] = resp.json()
            NEWS_CACHE['last_fetch'] = now
            print(f'[NEWS] Calendar updated: {len(NEWS_CACHE['data'])} events')
        except Exception as e:
            print(f'[NEWS ERROR] {e} - using cached data')
    return NEWS_CACHE['data']

def is_news_blackout(pair: str, window_minutes: int = 30) -> tuple[bool, str]:
    currency_a = pair[:3].upper()
    currency_b = pair[3:6].upper()
    
    events = fetch_news_calendar()
    now_utc = datetime.now(timezone.utc)
    
    for event in events:
        if event.get('impact', '').upper() != 'HIGH':
            continue
        currency = event.get('country', '').upper()
        if currency not in [currency_a, currency_b]:
            continue
        
        try:
            # Parse ISO date (e.g., 2026-03-26T12:00:00Z)
            dt_str = event['date'].replace('Z', '+00:00')
            event_time = datetime.fromisoformat(dt_str)
            
            delta = (event_time - now_utc).total_seconds() / 60
            # Block 30 mins before and 5 mins after
            if -5 <= delta <= window_minutes:
                return True, f'{event['title']} ({currency}) in {delta:.0f} mins'
        except Exception as e:
            continue
    
    return False, ''

if __name__ == '__main__':
    # Test fetch
    print('Testing news blackout check for EURUSD...')
    blackout, reason = is_news_blackout('EURUSD')
    print(f'Blackout: {blackout}, Reason: {reason}')
