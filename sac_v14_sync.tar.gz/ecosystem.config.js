module.exports = {
  apps: [
    {
      name: "SAC-BRAIN-V13.1",
      script: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/sipoma_autonomous.py",
      cwd: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD",
      interpreter: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/venv/bin/python3",
      env: {
        PYTHONPATH: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD"
      }
    },
    {
      name: "SAC-BOT-V13.1",
      script: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/ai_commander.py",
      cwd: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD",
      interpreter: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/venv/bin/python3"
    },
    {
      name: "SAC-MONITOR-V13.1",
      script: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/realtime_monitor.py",
      cwd: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD",
      interpreter: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/venv/bin/python3"
    },
    {
      name: "SAC-TICK-V13.1",
      script: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/tick_historian.py",
      cwd: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD",
      interpreter: "/home/ardilabayufirdaus/Desktop/SIPOMA-V13-PROD/venv/bin/python3"
    }
  ]
};
