import os
import logging
from typing import Dict
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - RISK-V14 - %(message)s")
logger = logging.getLogger(__name__)

class RiskManager:
    def __init__(self):
        self.risk_floor = 0.1
        self.risk_cap = 2.0
        self.min_lot = 0.01
        self.lot_step = 0.01

    def calculate_lot(self, equity, sl_pips, pair, risk_pct):
        """V14.0 Institutional Lot Calc: Risk_Amt / (SL_Pips * Pip_Val)"""
        try:
            # Detect tick values (Standard vs JPY)
            tick_size = 0.0001
            if "JPY" in pair: tick_size = 0.01
            elif "XAU" in pair: tick_size = 0.1
            
            risk_amt = equity * (risk_pct / 100)
            # pip_value_01 = (lot * 100k * tick_size) -> For standard
            # We assume 1 lot pip value mapping:
            # EURUSD 1 lot = $10 per pip
            # JPY 1 lot = $7-8 per pip (simplified to 7.5)
            pip_val_1lot = 10.0 if "JPY" not in pair else 7.5
            if "XAU" in pair: pip_val_1lot = 1.0 # Gold 1 lot = $1 per 0.1 pip move
            
            lot = risk_amt / (sl_pips * pip_val_1lot)
            final_lot = max(self.min_lot, round(lot / self.lot_step) * self.lot_step)
            return round(min(5.0, final_lot), 2)
        except:
            return self.min_lot

    def generate_trade_command(self, pair, action, entry, sl_dist, tp_dist, wr, equity):
        risk_pct = max(self.risk_floor, min(self.risk_cap, (wr * 2 - 1) * 100 / 2)) # Half-Kelly
        lot = self.calculate_lot(equity, sl_dist, pair, risk_pct)
        
        # SL/TP Absolute Price Calculation (Rule: Accuracy 100%)
        # Digit detection
        dg = 0.0001 if "JPY" not in pair else 0.01
        sl_price = entry - (sl_dist * dg) if action == "BUY" else entry + (sl_dist * dg)
        tp_price = entry + (tp_dist * dg) if action == "BUY" else entry - (tp_dist * dg)
        
        return {
            "pair": pair, "action": f"{action}_MARKET", "lot": lot,
            "sl": round(sl_price, 5), "tp": round(tp_price, 5), "risk": round(risk_pct, 2)
        }

risk_mgr = RiskManager()
