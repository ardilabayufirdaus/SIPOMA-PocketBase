import os
import json
import time
import asyncio
import sqlite3
import logging
import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# --- CONFIGURATION V14.0 ---
DB_PATH = "/home/ardilabayufirdaus/ai-commander/commander_v2.db"
MT4_FILES = "/home/ardilabayufirdaus/.wine/drive_c/Program Files (x86)/MetaTrader 4/MQL4/Files"
iSIGNAL_PATH = os.path.join(MT4_FILES, "signals.txt")
iPRICE_PATH = os.path.join(MT4_FILES, "price_data.txt")
iSTATS_PATH = os.path.join(MT4_FILES, "account_stats.txt")
iMODIFY_PATH = os.path.join(MT4_FILES, "modify.txt")
iCLOSE_PATH = os.path.join(MT4_FILES, "close.txt")

# 24/5 Optimized Intervals
SCAN_INTERVALS = {
    "TOKYO": 30,
    "LONDON": 10,
    "NEWYORK": 10,
    "SYDNEY": 30,
    "TRANSITION": 45  # Low liquidity gap (17-21 UTC)
}

CURRENT_STATS = {"equity": 0, "balance": 0, "trades": []}

logging.basicConfig(level=logging.INFO, format="%(asctime)s - V14.0-BRAIN - %(levelname)s - %(message)s")

def get_market_session():
    """Institutional 24/5 Session Matrix (UTC)"""
    hr = datetime.now(timezone.utc).hour
    if 0 <= hr < 7: return "TOKYO"
    if 7 <= hr < 12: return "LONDON"
    if 12 <= hr < 17: return "NEWYORK"
    if 21 <= hr <= 23: return "SYDNEY"
    return "TRANSITION"  # Gap 17:00 - 21:00 UTC

def get_dynamic_win_rate():
    try:
        conn = sqlite3.connect(DB_PATH)
        df = pd.read_sql_query("SELECT outcome FROM trade_history ORDER BY id DESC LIMIT 50", conn)
        conn.close()
        if df.empty: return 0.55
        wins = len(df[df["outcome"] == "WIN"])
        losses = len(df[df["outcome"] == "LOSS"])
        return wins / (wins + losses) if (wins + losses) > 0 else 0.55
    except: return 0.55

async def fetch_intermarket_v14():
    try:
        data = yf.download(["DX-Y.NYB", "GC=F", "^TNX"], period="1d", interval="1m", progress=False)
        if data.empty: return {}
        latest = data.iloc[-1]["Close"]
        return {
            "dxy": round(latest.get("DX-Y.NYB", 0), 2),
            "gold": round(latest.get("GC=F", 0), 2),
            "us10y": round(latest.get("^TNX", 0), 2)
        }
    except Exception as e:
        return {}

async def watchdog_task():
    while True:
        try:
            if os.path.exists(iSTATS_PATH):
                with open(iSTATS_PATH, "r") as f:
                    lines = f.readlines()
                    if lines and len(lines) > 0:
                        parts = lines[0].strip().split("|")
                        if len(parts) >= 2:
                            CURRENT_STATS["balance"] = float(parts[0])
                            CURRENT_STATS["equity"] = float(parts[1])
                        active_tickets = []
                        for line in lines[1:]:
                            if line.startswith("ORDER"):
                                p = line.strip().split("|")
                                if len(p) >= 9:
                                    active_tickets.append({
                                        "ticket": int(p[1]), "pair": p[2], "type": int(p[3]),
                                        "entry": float(p[4]), "profit": float(p[5]), 
                                        "sl": float(p[6]), "tp": float(p[7])
                                    })
                        CURRENT_STATS["trades"] = active_tickets

            for trade in CURRENT_STATS["trades"]:
                if trade["profit"] > 100:
                    new_sl = trade["entry"] + (trade["profit"] * 0.8 / 10)
                    if (trade["type"] == 0 and new_sl > trade["sl"]) or (trade["type"] == 1 and new_sl < trade["sl"]):
                        with open(iMODIFY_PATH, "a") as f:
                            f.write(f"{trade['ticket']}|{round(new_sl, 5)}|{trade['tp']}\n")
                        logging.info(f"V14-MOD: Ticket #{trade['ticket']} SL -> {new_sl}")
            await asyncio.sleep(1)
        except Exception as e:
            await asyncio.sleep(1)

async def scanner_task():
    while True:
        try:
            session = get_market_session()
            wr = get_dynamic_win_rate()
            intermarket = await fetch_intermarket_v14()
            logging.info(f"SESSION: {session} ACTIVE | WR: {round(wr*100,1)}% | Context: {intermarket}")
            await asyncio.sleep(SCAN_INTERVALS.get(session, 15))
        except Exception as e:
            await asyncio.sleep(15)

if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.create_task(watchdog_task())
    loop.create_task(scanner_task())
    loop.run_forever()
